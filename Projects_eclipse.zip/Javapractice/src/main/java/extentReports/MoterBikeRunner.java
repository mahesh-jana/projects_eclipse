package extentReports;

public class MoterBikeRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MoterBike ducati = new MoterBike();
		MoterBike honda = new MoterBike();
		ducati.start();
		honda.start();
		ducati.setSpeed(100);
		System.out.println(ducati.getSpeed());
		
		
		honda.setSpeed(299);
		System.out.println(honda.getSpeed());

	}

}
