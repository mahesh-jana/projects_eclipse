package extentReports;

public class MoterBike {
	private int speed;
	
	void setSpeed(int speed) {
		this.speed=speed;
	}
		int getSpeed() {
			return this.speed;
			
		}
	
	
	
	void start() {
		System.out.println("Bike is started");
		
	}
	
}
