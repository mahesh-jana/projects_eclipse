package encapulation;

public class MainEncapusulation {

	public static void main(String[] args) {
		
		Encapgetsetters accobj=new Encapgetsetters();
		accobj.setAcno(123);
		accobj.setAmount(10000);
		accobj.setName("mahi");
		
		
		System.out.println(accobj.getAcno());
		System.out.println(accobj.getAmount());
		System.out.println(accobj.getName());
		
	}

}
