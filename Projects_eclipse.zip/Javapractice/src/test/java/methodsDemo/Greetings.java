package methodsDemo;

public class Greetings {

	
	//no return value
void greetings1()	{
	
	System.out.println("Hello");
	
}
	
	//2)no params return value

String gree2() {
	
	return "Hello every one";
}
//3.takes parmetrs no return value
void gr3(String name) {
	System.out.println("the name is:"+name);
}
//4 takes paramerr return value

String gr4(int a) {

	return ("name"+a);
}




}
