package methodsDemo;

public class GreetingsMain {

	public static void main(String[] args) {
		
		Greetings gr1=new Greetings();
		gr1.greetings1();
		
		
		String str=gr1.gree2();
		System.out.println(str);
		gr1.gr3("mahesh");

		System.out.println(gr1.gr4(4));
		
	}

}
