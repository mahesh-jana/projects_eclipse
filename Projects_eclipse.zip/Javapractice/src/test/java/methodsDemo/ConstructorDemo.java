package methodsDemo;

public class ConstructorDemo {
	
	int x,y;
	String z;
	
	/*ConstructorDemo()
	{
		x=10;
		y=20;
		z="demo";
				
	}*/
	void dis()
	{
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
		
	}
	
	ConstructorDemo(int a,int b,String c)
	{
		x=a;
		y=b;
		z=c;
		
	}
	
	
	
	
	
	public static void main(String[] args) {
		
		ConstructorDemo cd=new ConstructorDemo(1,2,"mahi");
		//cd.dis();
		cd.dis();
		
		

	}

}
