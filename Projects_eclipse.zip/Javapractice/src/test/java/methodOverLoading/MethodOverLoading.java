package methodOverLoading;

public class MethodOverLoading {
	
	int x,y,z;
	double v;
	
	void sum() {
		
		x=10;
		y=20;
		
		System.out.println(x+y);
		
	}
	
	
	void sum(int a,int b,int c) {
		x=a;
		y=b;
		z=c;
		System.out.println(a+b+c);
		
		
		
	}
	void sum(int a,double b) {
		
	    x=a;
	    v=b;
		
	    System.out.println(x+v);
	}
	/*
	void MethodOverLoading(int x,int y) 
	{
		this.x=x;
		this.y=y;
		
		
	}*/
	
	
	
	
	public static void main(String[] args) {
		
		MethodOverLoading mo=new MethodOverLoading();
		//System.out.println(mo.sum(2, 3.5));
		mo.sum();
		mo.sum(4,3.5 );
		mo.sum(1, 2, 3);
		

		
		
	}

}
