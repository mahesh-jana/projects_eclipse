package Day1;

public class EmployeeDetail {
	String name;
	int age;

	public void details() {

		System.out.println("the name:" + name);
		System.out.println("the age:" + age);

	}

}
