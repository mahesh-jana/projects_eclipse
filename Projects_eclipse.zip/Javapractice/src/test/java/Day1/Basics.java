package Day1;

public class Basics {

	int price;

	String location;

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public static void main(String[] args) {
		Basics a = new Basics();
		a.setLocation("Hyderabad");
		a.setPrice(5000);
		System.out.println(a.getLocation());
		System.out.println(a.getPrice());

	}

}
