package Day1;

import java.util.Scanner;

public class Cognizant {

//	String name;
//	int salary;
//	int emp_id;

	public static void main(String[] args) {
		int de;
		System.out.println("Enter the details of Employee");

		Scanner sc = new Scanner(System.in);
		de = sc.nextInt();
//		int salary = sc.nextInt();
//		int emp_id = sc.nextInt();

		EmployeeDetail[] emp = new EmployeeDetail[de];

		for (int i = 0; i < emp.length; i++) {

			emp[i] = new EmployeeDetail();

			emp[i].age = sc.nextInt();
			emp[i].name = sc.next();

		}

	}

}
