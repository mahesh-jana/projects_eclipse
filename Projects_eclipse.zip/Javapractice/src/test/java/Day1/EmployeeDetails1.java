package Day1;

public class EmployeeDetails1 {

	String name;
	int age;
	int salary;
	String address;

	EmployeeDetails1() {

		salary = 22;

	}

	void display() {
		System.out.println(name);
		System.out.println(age);
		System.out.println(salary);
		System.out.println(address);
	}

	public static void main(String args[]) {
		EmployeeDetails1 ed = new EmployeeDetails1();

		ed.display();
	}
}
