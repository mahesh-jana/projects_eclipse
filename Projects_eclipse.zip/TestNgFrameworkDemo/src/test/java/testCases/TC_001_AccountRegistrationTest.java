package testCases;


import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.AccountRegistrationPage;
import pageObjects.HomePage;
import testBase.BaseClass;

public class TC_001_AccountRegistrationTest extends BaseClass {

	
	
	@Test
	void test_account_Registration()
	{ 
		
		logger.info("****starting TC_001_AccountRegistrationTest ***");
		try {
		HomePage hp=new HomePage(driver);
		hp.clickMyAccount();
		logger.info("clicked on my account link");
		hp.clickRegister();
		logger.info("clicked on rigister link");
		
		AccountRegistrationPage regpage= new AccountRegistrationPage(driver);
		logger.info("providing customer data");
		
		regpage.setFirstName(randomString());
		regpage.setLastName(randomString());
		regpage.settxtEmail(randomString()+"@gmail.com"); //random string
		regpage.settxtPassword(randomAlphaNumeric());
		//regpage.setchkdPolicy();
		//regpage.clickbtnContinue();
		/*logger.info("clicked on continue");
		
		String confmsg=regpage.msgConfirmation();
		logger.info("validating expected message");*/
		
		Assert.assertEquals(1,1);
	} catch(Exception e) 
	{
	logger.error("test failed");
	Assert.fail();
	}
	}
	
}
