package snippet;

public class Snippet {
	<?xml version="1.0" encoding="UTF-8"?>
	<Configuration status="WARN">
	
	<Properties>
	<Property> name="basePath">./logs</Property>
	</properties>
	
	  <Appenders>
	    <Console name="Console" target="SYSTEM_OUT">
	      <PatternLayout pattern="%d{HH:mm:ss.SSS} [%t] %-5level %logger{36} - %msg%n"/>
	    </Console>
	    
	    <RollingFile name="File" fileName"${basePath}/automation.log" filePattern="${basePath}/automation-%d{yyyy-MM-dd}.log">
	    </RollingFile>
	  </Appenders>
	  <Loggers>
	    <Logger name="com.foo.Bar" level="trace" additivity="false">
	      <AppenderRef ref="File"/>
	    </Logger>
	    <Root level="Info">
	      <AppenderRef ref="Console"/>
	    </Root>
	  </Loggers>
	</Configuration>
}

