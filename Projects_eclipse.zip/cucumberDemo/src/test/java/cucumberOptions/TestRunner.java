package cucumberOptions;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

//feature
@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/java/features", glue = "stepDefinations", monochrome = true, dryRun = true)

/*
 * monochrome =true-->the console output and reports generated will be in a
 * simple,singe-colour format without any additional styling or colour
 * coding,this makes reports can easily read and understood.
 * 
 * 
 * dryrun=true -->when this option is enabled ,cucumber will perform a "dry run"
 * of the features files without actually executing the steps defined in the
 * step definations. during the dryrun,cucumber will check if all the steps in
 * the feature files have matching step definations it helpsquickly identifying
 * any missing or unidentified steps without actually executing the tests,which
 * can be useful for debugging or ensuring the completeness of stepdefinations
 * before running the fullsuite of tests
 * 
 * background=In Cucumber, the Background keyword is used to group multiple
 * Given statements into a single group. It is used to define pre-conditions for
 * all scenarios, and is often used when the same set of Given statements are
 * repeated in each scenario of the feature file. The Background keyword is run
 * before each scenario, but after any of the @Before hook.
 */

public class TestRunner {

}
