package collections;

import java.util.ArrayList;
import java.util.HashSet;

public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet myset = new HashSet();

		// Set myset1=new HashSet();

		// HashSet<String> myset = new HashSet<String>();

		// adding elements
		myset.add("mahesh");
		myset.add(100);
		myset.add('j');
		myset.add(true);

		System.out.println(myset);

		// Removing element-->myset.remove(100);

		// inserting element --Not possible
		// Acess specific element --not possible

		// convert hashset into arraylist

		ArrayList al = new ArrayList(myset);

		System.out.println(al.get(1));

		// read data by for each and iterator

	}

}
