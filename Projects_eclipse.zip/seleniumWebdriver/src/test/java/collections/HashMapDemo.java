package collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// declaration
		// HashMap hm=new HashMap();
		// Map hm=new HashMap();

		HashMap<Integer, String> hm = new HashMap<Integer, String>();

		// Adding pairs

		hm.put(101, "mahi");
		hm.put(102, "mahesh");
		hm.put(103, "jana");
		hm.put(104, "mahhi");
		hm.put(105, "mah");

		System.out.println(hm);

		// remove pair

		hm.remove(104);

		System.out.println("After removing" + hm);

		System.out.println(hm.keySet());
		System.out.println(hm.values());
		System.out.println(hm.entrySet());

		// Reading data from the hashmap

		// using for..each

		for (int k : hm.keySet()) {
			System.out.println(k + "  " + hm.get(k));

		}
		// Iterator

		Iterator<Entry<Integer, String>> it = hm.entrySet().iterator();

		while (it.hasNext()) {

			Entry<Integer, String> entry = it.next();
			System.out.println(entry.getKey() + "  " + entry.getValue());
		}

	}

}
