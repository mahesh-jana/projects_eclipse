package collections;

import java.util.ArrayList;
import java.util.Iterator;

public class List {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Declaration
		ArrayList myList = new ArrayList();

		// List mylist=new ArrayList();

		// ArrayList <String>mylist=new ArrayList<String>();

		myList.add(100);
		myList.add("mahesh");
		myList.add('a');
		myList.add(true);
		myList.add(null);
		myList.add(null);

		System.out.println("printling data from the list collection is:" + myList);
		System.out.println(myList.size());

		// remove element

		myList.remove(2);
		System.out.println("After removing the element:" + myList);

		// inserting a element:It will add at the middle by what we mention as index)
		// where as add method will add the element at the end;

		myList.add(2, "jana");
		System.out.println("After inserting the element:" + myList);

		// myList .set-->is uesd to replace/modify/change of particular element
		// myList.get-->is used to acess the particular element

		// reading all elements from arrayList

		// 1)Normal for loop
		// 2)For each loop
		// 3)By using Iterator

		for (int i = 0; i < myList.size(); i++) {
			System.out.println(myList.get(i));
		}

		// ForEach LOOP

		for (Object li : myList) {
			System.out.println(li);
		}

		// Iterator

		Iterator<Object> it = myList.iterator();

		while (it.hasNext()) {

			System.out.println(it.next());
		}

	}

}
