package browserWindowHandles;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserwindHandles {

	public static void main(String[] args) throws InterruptedException {

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("OrangeHRM, Inc")).click();
		// Set<String> ids=driver.getWindowHandles();

		// approach 1

		Set<String> ids = driver.getWindowHandles();

		// approach 1
		/*
		 * List <String>windowids=new ArrayList(ids); String
		 * parentwindowid=windowids.get(0); String childwindowid=windowids.get(1);
		 * 
		 * //switch to child window driver.switchTo().window(childwindowid);
		 * driver.findElement(By.xpath("//input[@id='Form_getForm_Email']")).sendKeys(
		 * "mah@123.com"); driver.switchTo().window(parentwindowid);
		 * driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys(
		 * "Admin");
		 */
		Thread.sleep(3000);
		/*
		 * for(String winidd:ids) {
		 * 
		 * String title=driver.switchTo().window(winidd).getTitle();
		 * 
		 * if(title.
		 * equals("OrangeHRM HR Software | Free & Open Source HR Software | HRMS | HRIS | OrangeHRM)"
		 * )); {
		 * driver.findElement(By.xpath("//input[@id='Form_getForm_Email']")).sendKeys(
		 * "mah@123.com"); } }
		 */

		for (String winidd : ids) {

			String title = driver.switchTo().window(winidd).getTitle();
			if (title.equals("OrangeHRM")) {
				driver.close();
			}

		}

	}

}
