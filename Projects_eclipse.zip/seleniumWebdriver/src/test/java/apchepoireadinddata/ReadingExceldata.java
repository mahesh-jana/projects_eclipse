package apchepoireadinddata;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//File-->workbook-->sheets-->Rows--->cells
public class ReadingExceldata {

	public static void main(String[] args) throws IOException  {
		
		
		                                          //system.getproperty("user.dir")+\\
		FileInputStream file=new FileInputStream(System.getProperty("user.dir")+"\\Testdata\\Book1.xlsx");
		
		XSSFWorkbook workbook=new XSSFWorkbook(file);

		XSSFSheet sheet=workbook.getSheet("Sheet1");//or index
		
		int totalrows=sheet.getLastRowNum();
		int totalcells=sheet.getRow(1).getLastCellNum();
		
		System.out.println("no of rows:"+totalrows);
		System.out.println("no of cells:"+totalcells);
		
		for(int r=0;r<=totalrows;r++)
		{
			XSSFRow currentRow=sheet.getRow(r);
			for(int c=0;c<totalcells;c++)
			{
				//XSSFCell cell=CurrentRow.getCell(c);
				//String value=cell.toString();
				String value=currentRow.getCell(c).toString();
				System.out.print(value+"      ");
			}
			System.out.println();
		}
		
		workbook.close();
		file.close();
		
	}

}
