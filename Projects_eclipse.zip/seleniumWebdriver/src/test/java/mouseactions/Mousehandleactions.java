package mouseactions;

public class Mousehandleactions {

	public static void main(String[] args) {
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver = new ChromeDriver();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//
//		// mouse hover: driver.get("https://demo.opencart.com/");
//		driver.manage().window().maximize();
//
//		WebElement desktops = driver.findElement(By.xpath("//a[normalize-space()='Desktops']"));
//		WebElement mac = driver.findElement(By.xpath("//a[normalize-space()='Mac (1)']"));
//
//		Actions act = new Actions(driver); // move element,mouse hover action
//		act.moveToElement(desktops).moveToElement(mac).click().build().perform();
//
//		// right click:
//		driver.get("https://swisnl.github.io/jQuery-contextMenu/demo.html");
//		driver.manage().window().maximize();
//		WebElement button = driver.findElement(By.xpath("//span[@class='context-menu-one btn btn-neutral']"));
//		Actions act = new Actions(driver);
//		act.contextClick(button).perform();
//		Actions act1 = new Actions(driver);
//		act1.contextClick(button).perform();
//
//		// driver.findElement(By.xpath("//span[normalize-space()='Copy']")).click();
//		// driver.switchTo().alert().accept();
//
//		// double click
//		driver.get("https://demo.guru99.com/test/simple_context_menu.html");
//		driver.manage().window().maximize();
//		WebElement button = driver.findElement(By.xpath("//button[@ondblclick='myFunction()']"));
//		Actions act3 = new Actions(driver);
//		act3.doubleClick(button).perform();
//
//		// same:act.doubleClick(button).perform();
//
//		// Drag and drop
//		// same-->source element,target element find the element
//		// act.dragAndDrop(source,italy).perform();
//
//		// Slider
//
//		driver.get("https://www.jqueryscript.net/demo/Price-Range-Slider-jQuery-UI/");
//		driver.manage().window().maximize();
//
//		Actions act4 = new Actions(driver);
//
//		WebElement min_slider = driver.findElement(By.xpath("//span[1]"));
//		System.out.println("current location of min slider:" + min_slider.getLocation());
//		act4.dragAndDropBy(min_slider, 100, 250).perform();
//		System.out.println("location of min slider After moving:" + min_slider.getLocation());

	}

}
