package TestngDemo;

import org.testng.Assert;
import org.testng.annotations.Test;

public class FirstTest {
	
	@Test
	void test1()
	{
		System.out.println("testing 1");
		//Assert.assertTrue(true);
	}
	@Test
	void test2()
	{
	System.out.println("testing 2");
	}
	@Test
	void test3()
	{
		System.out.println("testinng 3");
	}
	
	
}
