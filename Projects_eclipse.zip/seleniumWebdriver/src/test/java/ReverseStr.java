import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ReverseStr {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.co.in/");
		driver.manage().window().maximize();

		String s = "mahesh";
		String s1 = "";
		char ch;

		for (int i = 0; i < s.length(); i++) {
			ch = s.charAt(i);
			s1 = ch + s1;
		}
		System.out.println(s1);

		// String Buffer
		String a = "ABCD";

		StringBuffer str = new StringBuffer(a);
		System.out.println(str.reverse());

		// Converting String to character array

		String str1 = "mahi";

		// char[] charry = str1.toCharArray();

		for (int i = str1.length() - 1; i >= 0; i--) {

			System.out.print(str1.charAt(i));
		}

	}

}
