package methodsdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Conditionaldemo {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/register?returnUrl=%2Fhtc-one-m8-android-l-50-lollipop");
		driver.manage().window().maximize();
		// WebElement logo=driver.findElement(By.xpath("//img[@alt='nopCommerce demo
		// store']"));
		// System.out.println(logo.isDisplayed());
		boolean status = driver.findElement(By.xpath("//img[@alt='nopCommerce demo store']")).isDisplayed();
		/*
		 * System.out.println(status); WebElement
		 * searchbox=driver.findElement(By.xpath("//input[@id='small-searchterms']"));
		 * System.out.println(searchbox.isEnabled());
		 * System.out.println(searchbox.isDisplayed());
		 */

		// is selected
		WebElement male_rd = driver.findElement(By.xpath("//input[@id='gender-male']"));
		WebElement female_rd = driver.findElement(By.xpath("//input[@id='gender-female']"));
		System.out.println(male_rd.isSelected());
		System.out.println(female_rd.isSelected());
		male_rd.click();
		System.out.println(male_rd.isSelected());
		System.out.println(female_rd.isSelected());

	}

}
