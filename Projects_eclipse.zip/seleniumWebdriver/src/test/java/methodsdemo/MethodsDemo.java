package methodsdemo;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MethodsDemo {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver= new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		String title=driver.getTitle();
		System.out.println(title);
		System.out.println("current url:" + driver.getCurrentUrl());
		//System.out.println( "The page source............:" + driver.getPageSource());
		//System.out.println(driver.getWindowHandle());
		//System.out.println(driver.getWindowHandles());
		Thread.sleep(5000);
		driver.findElement(By.linkText("OrangeHRM, Inc")).click();
		Set<String> ids=driver.getWindowHandles();
			
	 for(String winid:ids)  {
		 System.out.println(winid);
	 }

	}

}
