package checkboxes;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CheckboxDemo {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://itera-qa.azurewebsites.net/home/automation");
		driver.manage().window().maximize();
		// driver.findElement(By.xpath("//input[@id='monday']")).click();
		List<WebElement> checkboxs = driver
				.findElements(By.xpath("//input[@class='form-check-input' and @type='checkbox']"));
		System.out.println("checkboxes :" + checkboxs.size());

		// select all checkboxes
		/*
		 * for(int i=0;i<checkboxs.size();i++) { checkboxs.get(i).click();
		 * 
		 * }
		 */

		/*
		 * for(WebElement checkbx:checkboxs) { checkbx.click(); }
		 */
		for (int i = 4; i < checkboxs.size(); i++) {
			checkboxs.get(i).click();

		}
		for (int i = 0; i < 3; i++) {
			checkboxs.get(i).click();

		}

	}

}
