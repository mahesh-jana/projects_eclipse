
package MouseEvents;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SliderDemo {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver;
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		String URL = "http://www.seleniumeasy.com/test/drag-drop-range-sliders-demo";

		driver.get(URL);

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		Thread.sleep(3000);
		Actions builder = new Actions(driver);

		WebElement draggablePartOfScrollbar = driver
				.findElement(By.xpath("/html/body/div[2]/div/div[2]/section/div[1]/div[1]/div/input"));
		// To get pixel count of Slider X axis and Y axis(267,25)

		Dimension sliderWidth = draggablePartOfScrollbar.getSize();
		System.out.println(sliderWidth);

		// We need to give below value in +00 to move slider to 50 and +130 to move
		// slider to 100,-100 to move slider to 12
		int numberOfRangeToDragTheSlider = -100;
		builder.moveToElement(draggablePartOfScrollbar).clickAndHold().moveByOffset(numberOfRangeToDragTheSlider, 0)
				.release().perform();

	}
}