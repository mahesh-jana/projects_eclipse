package stepDefinations;

import java.util.Iterator;
import java.util.Set;

import org.testng.Assert;

import io.cucumber.java.en.Then;
import pageObjects.LandingPage;
import pageObjects.OffersPage;
import pageObjects.PageObjectManager;
import utils.TestContextSetup;

public class OfferPageStepDefination {

	public String offerPageProductName;
	TestContextSetup testContextSetup;
	PageObjectManager pageObjectManager;
	// single responsibility principle
	// loosly coupled
	// Factory Design Pattern

	public OfferPageStepDefination(TestContextSetup testContextSetup) {
		this.testContextSetup = testContextSetup;
	}

	@Then("user searched for  {string}  shortname in offers page")
	public void user_searched_for_shortname_in_offers_page(String string) throws InterruptedException {
		// offerpage->enter->grabtext
		// switchToOfferPage();
		OffersPage offerpage = new OffersPage(testContextSetup.driver);
		offerpage.searchItem(string);
		// testContextSetup.driver.findElement(By.xpath("//input[@type='search']")).sendKeys(string);
		Thread.sleep(2000);
		// offerPageProductName = testContextSetup.driver.findElement(By.cssSelector("tr
		// td:nth-child(1)")).getText();
		offerPageProductName = offerpage.getProductName();
	}

	public void switchToOfferPage() {
		// switch to offerpage--> skip below part

		// pageObjectManager = new PageObjectManager(testContextSetup.driver);
		LandingPage landingPage = testContextSetup.PageObjectManager.getLandingPage();

		landingPage.selectTopDealsPage();
		Set<String> s1 = testContextSetup.driver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();
		String parentWindow = i1.next();
		String childWindow = i1.next();
		testContextSetup.driver.switchTo().window(childWindow);
	}

	@Then("validate product name in offers page matches with Landing page")
	public void validate_product_name_in_offers_page() {
		Assert.assertEquals(offerPageProductName, testContextSetup.landingPageproductName);
	}
}
