package testng.testbase;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase {

	public static WebDriver driver;
	public static ExtentReports extent;
	public static ExtentTest test;
	public ITestResult result;
	
	// private final Logger log = LoggerHelper.getLogger(TestBase.class);
		public Properties OR = new Properties();

		static {
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
			extent = new ExtentReports(System.getProperty("user.dir") + "\\src\\main\\java\\com\\testng\\reports\\"
					+ formater.format(calendar.getTime()) + "_Report.html", false);

		}
		
		public void loadData() throws IOException {
			File file = new File(
					System.getProperty("user.dir") + ".\\src\\main\\java\\Config\\testng\\config.properties");
			FileInputStream f = new FileInputStream(file);
			OR.load(f);

		}

		public String getdata(String key) {
			try {
				loadData();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return OR.getProperty(key);
		}

		public void getresult(ITestResult result) {
			if (result.getStatus() == ITestResult.SUCCESS) {
				test.log(LogStatus.PASS, result.getName() + " test is pass");
				String screen = captureScreen("");
				test.log(LogStatus.PASS, test.addScreenCapture(screen));
			} else if (result.getStatus() == ITestResult.SKIP) {
				test.log(LogStatus.SKIP,
						result.getName() + " test is skipped and skip reason is:-" + result.getThrowable());
			} else if (result.getStatus() == ITestResult.FAILURE) {
				test.log(LogStatus.ERROR, result.getName() + " test is failed" + result.getThrowable());
				String screen = captureScreen("");
				test.log(LogStatus.FAIL, test.addScreenCapture(screen));
			} else if (result.getStatus() == ITestResult.STARTED) {
				test.log(LogStatus.INFO, result.getName() + " test is started");
			}
		}
		
		public void selectBrowser(BrowserType browser) {

			switch (browser) {
			case chrome:
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
				break;

			case firefox:
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver();
				break;

			case safari:
				WebDriverManager.safaridriver().setup();
				driver = new SafariDriver();
				break;

			case edge:
				WebDriverManager.edgedriver().setup();
				driver = new EdgeDriver();
				break;

			case ie:
				WebDriverManager.iedriver().setup();
				driver = new InternetExplorerDriver();
				break;

			default:
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
				break;
			}
		}
		
		public void enterURL(String url) {
			driver.get(url);
			{
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			}
		}

		public void init() {
			selectBrowser(BrowserType.chrome);
			enterURL(getdata("url"));
		}

		public String captureScreen(String fileName) {
			if (fileName == "") {
				fileName = "blank";
			}
			File destFile = null;
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");

			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

			try {
				String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath()
						+ "\\src\\main\\java\\com\\testng\\ScreenShots\\";
				destFile = new File(
						(String) reportDirectory + fileName + "_" + formater.format(calendar.getTime()) + ".png");
				FileUtils.copyFile(scrFile, destFile);
				// This will help us to link the screen shot in testNG report
				Reporter.log("<a href='" + destFile.getAbsolutePath() + "'> <img src='" + destFile.getAbsolutePath()
						+ "' height='100' width='100'/> </a>");
			} catch (IOException e) {
				e.printStackTrace();
			}
			return destFile.toString();
		}
		
		public String captureScreen(String fileName, String reportDirectory) {
			if (fileName == "") {
				fileName = "blank";
			}
			File destFile = null;
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");

			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

			try {
				destFile = new File(
						(String) reportDirectory + fileName + "_" + formater.format(calendar.getTime()) + ".png");
				FileUtils.copyFile(scrFile, destFile);
				// This will help us to link the screen shot in testNG report
				Reporter.log("<a href='" + destFile.getAbsolutePath() + "'> <img src='" + destFile.getAbsolutePath()
						+ "' height='100' width='100'/> </a>");
			} catch (IOException e) {
				e.printStackTrace();
			}
			return destFile.toString();
		}

		public void closeBrowser() {
			driver.quit();
			extent.endTest(test);
			extent.flush();
		}

		@AfterMethod
		public void afterMethod(ITestResult result) {
			getresult(result);
		}

		@BeforeMethod()
		public void beforeMethod(Method result) {
			test = extent.startTest(result.getName());
			test.log(LogStatus.INFO, result.getName() + " test Started");
			
		}

		@AfterClass(alwaysRun = true)
		public void endTest() {
		//	closeBrowser();
		}

	
}
