package testng.testbase;

public enum BrowserType {
	
	chrome, firefox, edge, safari, ie;
	
}
