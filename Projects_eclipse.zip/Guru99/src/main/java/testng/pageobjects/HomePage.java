package testng.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import testng.testbase.TestBase;

public class HomePage extends TestBase {
	
	@FindBy(name = "uid")
	private WebElement txt_UserId;

	@FindBy(name = "password")
	private WebElement txt_Password;

	@FindBy(name = "btnLogin")
	private WebElement btn_Login;
	
	@FindBy(xpath="/html/body/div[3]/div/ul/li[15]/a")
	private WebElement btn_Logout;

	
	@FindBy(xpath = "//ul[@class='menusubnav']/li/a")
	private List<WebElement> allOptions;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getTxt_UserId() {
		return txt_UserId;
	}

	public WebElement getTxt_Password() {
		return txt_Password;
	}

	public WebElement getBtn_Login() {
		return btn_Login;
	}
	public WebElement getBtn_Logout() {
		return btn_Logout;
	}

	public List<WebElement> getAllOptions() {
		return allOptions;
	}

	public void HomePage(String userId, String password) {
		getTxt_UserId().sendKeys(userId);
		getTxt_Password().sendKeys(password);
		getBtn_Login().click();
		getBtn_Logout().click();
	}

}
