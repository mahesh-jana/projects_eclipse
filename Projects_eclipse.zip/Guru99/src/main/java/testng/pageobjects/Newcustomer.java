package testng.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import testng.testbase.TestBase;

public class Newcustomer extends TestBase{
	
	@FindBy(name = "uid")
	private WebElement txt_UserId;

	@FindBy(name = "password")
	private WebElement txt_Password;

	@FindBy(name = "btnLogin")
	private WebElement btn_Login;
	
	@FindBy(xpath="/html/body/div[3]/div/ul/li[2]/a")
	private WebElement btn_newcustomer;
	
	@FindBy(name="name")
	private WebElement txt_customername ;

	@FindBy(name = "dob")
	private WebElement txt_dob;
	
	@FindBy(name = "addr")
	private WebElement txt_address ;
	
	@FindBy(name="city")
	private WebElement txt_city ;
	
	@FindBy(name="state")
	private WebElement txt_state;
	
	@FindBy(name="pinno")
	private WebElement txt_pin;
	
	@FindBy(name="telephoneno")
	private WebElement txt_mobnum;
	
	@FindBy(name="emailid")
	private WebElement txt_email;

	@FindBy(name="password")
	private WebElement txt_passwrd;
	
	@FindBy(name="sub")
	private WebElement btn_submit;
	
	@FindBy(xpath = "//ul[@class='menusubnav']/li/a")
	private List<WebElement> allOptions;
	
	
	public Newcustomer(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getTxt_UserId() {
		return txt_UserId;
	}

	public WebElement getTxt_Password() {
		return txt_Password;
	}

	public WebElement getBtn_Login() {
		return btn_Login;
	}
	
	public WebElement getBtn_newcustomer() {
		return btn_newcustomer;
	}
	
	public WebElement getTxt_customername() {
		return txt_customername;
	}
	public WebElement getTxt_dob() {
		return txt_dob;
	}
	public WebElement getTxt_address() {
		return txt_address;
	}
	public WebElement getTxt_city() {
		return txt_city;
	}
	public WebElement getTxt_state() {
		return txt_state;
	}
	public WebElement getTxt_pin() {
		return txt_pin;
	}
	public WebElement getTxt_mobnum() {
		return txt_mobnum;
	}
	public WebElement getTxt_email() {
		return txt_email;
	}
	public WebElement getTxt_passwrd() {
		return txt_passwrd;
	}
	public WebElement getTxt_submit() {
		return btn_submit;
	}

	
	public List<WebElement> getAllOptions() {
		return allOptions;
	}

	public void Newcustomer(String userId, String password) {
		getTxt_UserId().sendKeys(userId);
		getTxt_Password().sendKeys(password);
		getBtn_Login().click();
		getBtn_newcustomer().click();
		getTxt_customername().sendKeys(getdata("firstname"));
		getTxt_dob().sendKeys(getdata("dateofbirth"));
		getTxt_address().sendKeys(getdata("add"));
		getTxt_city().sendKeys(getdata("city"));
		getTxt_state().sendKeys(getdata("state"));
		getTxt_pin().sendKeys(getdata("pin"));
		getTxt_mobnum().sendKeys(getdata("mobnum"));
		getTxt_email().sendKeys(getdata("email"));
		getTxt_passwrd().sendKeys(getdata("passwrd"));
		getTxt_submit().click();


	}
}
