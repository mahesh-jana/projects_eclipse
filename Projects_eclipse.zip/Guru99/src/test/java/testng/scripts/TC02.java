package testng.scripts;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import testng.pageobjects.Newcustomer;
import testng.testbase.TestBase;

public class TC02 extends TestBase {	
	
	@BeforeMethod
	public void testStart() {
		init();
	}

	@Test
	public void verifyNewCustomer() {
		Newcustomer Newcustomer  = new Newcustomer(driver);
		System.out.println("************Perform  test started ********");
		Newcustomer.Newcustomer(getdata("userId"), getdata("password"));
		System.out.println("************Perform  test ended ********");

		
	}

}
