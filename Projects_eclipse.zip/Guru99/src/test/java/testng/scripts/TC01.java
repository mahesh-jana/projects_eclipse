package testng.scripts;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import testng.pageobjects.HomePage;
import testng.testbase.TestBase;

public class TC01 extends TestBase  {
	@BeforeMethod
	public void testStart() {
		init();
	}

	@Test
	public void verifyHomePage() {
		HomePage HomePage  = new HomePage(driver);
		System.out.println("************Perform loginOperation test started ********");
		System.out.println(getdata("userId"));
		System.out.println(getdata("password"));
		HomePage.HomePage(getdata("userId"), getdata("password"));
		
		System.out.println("************Perform logoutOperation test finished ********");

	}

}
