package writingexcel;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class writingexcel {

	public static void main(String[] args) throws IOException {
		FileOutputStream file=new FileOutputStream(System.getProperty("user.dir")+"\\data\\writing.xlsx");
		XSSFWorkbook workbook=new XSSFWorkbook();
		XSSFSheet sheet=workbook.createSheet();
		for(int r=0 ; r<=5;r++) {
			XSSFRow currentrow=sheet.createRow(r);
			for(int c=0;c<=3;c++) {
				currentrow.createCell(c).setCellValue("harsha ");
			}
		}
		workbook.write(file);
		workbook.close();
		file.close();
		System.out.println("writing is done");

		
	}

}
