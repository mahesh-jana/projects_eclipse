package Locators;

import org.testng.annotations.Test;

public class Testng {

	@Test
	public void demo()
	{
		System.out.println("hello");
	}
	

}
