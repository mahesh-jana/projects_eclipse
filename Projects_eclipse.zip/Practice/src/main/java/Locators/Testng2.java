package Locators;

import org.testng.annotations.Test;

public class Testng2 {

	@Test
	public void exp() {
		System.out.println("its okay");
		
	}
	
}
