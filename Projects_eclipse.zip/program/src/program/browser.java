package program;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class browser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//invoke browser
		//System.setProperty("webdriver.edge.driver","\\Users\\2118805\\Downloads\\edgedriver_win64.exe");
     // WebDriver driver= new EdgeDriver();
      System.setProperty("webdriver.edge.driver","C:\\Users\\2118805\\Downloads\\edgedriver_win64.zip");

      WebDriver driver = new EdgeDriver();
      driver.get("https://rahulshettyacademy.com");
	}

}
