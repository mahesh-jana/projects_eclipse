package program;

public class primeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number=11;
		int temp=0;
		for(int i=2;i<=number/2;i++)
			if(number%i==0) {
				temp=temp+1;
				break;
			}
		if(temp==0) {
			System.out.println("number is prime" );
		}
			else
			{
				System.out.println("number is not prime");
			}
		}

	}


