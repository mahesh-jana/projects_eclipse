package program;

public class len {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="jana mahesh kuruma";
		String[] splittedString=s.split("mahesh");
		System.out.println(splittedString[1]);
		for(int i=0;i<s.length();i++)
{
	System.out.println(s.charAt(i));
}
		for(int i=s.length()-1;i>=0;i--)
		{
			System.out.println(s.charAt(i));
		}
				
				

	}

}
